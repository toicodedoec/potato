# ingestion-standalone

Standalone package extracted from the Nx `ingestion` library with unchanged source behavior and local `@rag/*` compatibility stubs.

## Setup

```bash
npm install
```

## Scripts

- `npm run typecheck` - TypeScript check only
- `npm run build` - Compile to `dist/` and rewrite `@rag/*` aliases

## Required environment variables

- `OPENAI_API_KEY`
- `OPENAI_EMBEDDING_MODEL`
- `OPENAI_AZURE_API_HOST` (optional, when Azure OpenAI is used)
- `OPENAI_AZURE_API_ADA_VERSION` (optional, when Azure OpenAI is used)
- `PDF_EXTRACTOR_TYPE` (`pdf2json`, `pdfIngestion`, or `unstructured`)
- `PDF_INGESTION_SERVICE_URL` (required for `pdfIngestion`)
- `PDF_INGESTION_USE_GPT` (`true`/`false`, used by `pdfIngestion`)
- `UNSTRUCTURED_INGESTION_SERVICE_URL` (required for `unstructured`)
- `WEAVIATE_HOST` (optional, default `localhost`)
- `WEAVIATE_PORT` (optional, default `8080`)
- `WEAVIATE_GRPC_PORT` (optional, default `50051`)
- `WEAVIATE_API_KEY` (optional)
