import axios from "axios";
import { unlink } from "node:fs/promises";
import { writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { extname, join } from "node:path";
import { randomUUID } from "node:crypto";
import weaviate from "weaviate-client";

export async function getWeaviateClient() {
  const host = process.env["WEAVIATE_HOST"] ?? "localhost";
  const port = Number(process.env["WEAVIATE_PORT"] ?? "8080");
  const grpcPort = Number(process.env["WEAVIATE_GRPC_PORT"] ?? "50051");
  const apiKey = process.env["WEAVIATE_API_KEY"];

  return weaviate.connectToLocal({
    host,
    port,
    grpcPort,
    authCredentials: apiKey ? new weaviate.ApiKey(apiKey) : undefined,
  });
}

export async function downloadFileToTmp(url: string): Promise<string> {
  const response = await axios.get<ArrayBuffer>(url, {
    responseType: "arraybuffer",
  });
  const sourceExt = extname(new URL(url).pathname) || ".tmp";
  const localPath = join(tmpdir(), `ingestion-${randomUUID()}${sourceExt}`);
  await writeFile(localPath, Buffer.from(response.data));
  return localPath;
}

export async function deleteFileFromTmp(path: string): Promise<void> {
  try {
    await unlink(path);
  } catch (error) {
    console.warn(`Failed to delete temporary file ${path}`, error);
  }
}
