export const joinUrlSegments = (...segments: (string | undefined | null)[]) => {
  const filtered = segments.filter(Boolean) as string[];
  if (filtered.length === 0) {
    return "";
  }

  const [first, ...rest] = filtered;
  const normalizedFirst = first.replace(/\/+$/, "");
  const normalizedRest = rest.map((segment) =>
    segment.replace(/^\/+/, "").replace(/\/+$/, "")
  );
  return [normalizedFirst, ...normalizedRest].join("/");
};
