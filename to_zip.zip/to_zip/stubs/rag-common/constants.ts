export const INGESTION_MODES = [
  "pdf2json",
  "pdfIngestion",
  "unstructured",
] as const;

export type IngestionMode = (typeof INGESTION_MODES)[number];
