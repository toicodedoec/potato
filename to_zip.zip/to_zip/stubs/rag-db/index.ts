import { PrismaClient } from "@prisma/client";

export enum DocumentStatus {
  failed = "failed",
  unvectorized = "unvectorized",
  in_progress = "in_progress",
  vectorized = "vectorized",
}

export enum VectorizationConfiguration {
  simpleChunking = "simpleChunking",
  semanticChunking = "semanticChunking",
}

export interface DocumentMetadata {
  key: string;
  value: string;
}

export interface Document {
  id: string;
  applicationId: string;
  status: DocumentStatus;
  filePath: string;
  fileHost: string;
  name: string;
  priority: number;
  ingestionMode?: "pdf2json" | "pdfIngestion" | "unstructured" | null;
  vectorizationConfiguration?: VectorizationConfiguration | null;
}

const globalForPrisma = globalThis as unknown as {
  prismaStandalone?: PrismaClient;
};

const getPrismaClient = () => {
  if (!globalForPrisma.prismaStandalone) {
    globalForPrisma.prismaStandalone = new PrismaClient();
  }
  return globalForPrisma.prismaStandalone;
};

export const prisma = new Proxy({} as PrismaClient, {
  get(_target, property) {
    const client = getPrismaClient();
    const value = (client as unknown as Record<PropertyKey, unknown>)[property];
    return typeof value === "function" ? (value as Function).bind(client) : value;
  },
});
