export { processDocumentsApplication } from "./lib/agentDocumentProcessing";
export * from "./lib/collection";
export {
  updateNumberOfPages,
  UpdateNumberOfPagesResult,
} from "./lib/page-count-extractor";
