import { INGESTION_MODES } from "@rag/common/constants";
import { joinUrlSegments } from "@rag/common/utils";
import { Document, prisma } from "@rag/db";

import pdfExtractor from "./file-handling/pdf-handling/pdf-extraction/pdf-extractor";

export interface UpdateNumberOfPagesResult {
  successCount: number;
  failCount: number;
}

export async function updateNumberOfPages(
  docs: Document[]
): Promise<UpdateNumberOfPagesResult> {
  if (docs.length === 0) {
    console.warn("No documents to update page count");
    return {
      successCount: 0,
      failCount: 0,
    };
  }

  let successCount = 0;
  let failCount = 0;
  for (const doc of docs) {
    try {
      if (doc.ingestionMode && !INGESTION_MODES.includes(doc.ingestionMode)) {
        throw new Error("No correct ingestion mode provided");
      }

      const docUrl = joinUrlSegments(doc.fileHost, doc.filePath);
      const extractor = pdfExtractor(doc.ingestionMode ?? undefined);
      const pages = await extractor.extractPDF(docUrl);

      await prisma.document.update({
        where: {
          id: doc.id,
        },
        data: {
          pageCount: pages.length,
        },
      });
      successCount++;
    } catch (error) {
      console.error(
        `Error extracting page count of document ${doc.name}:`,
        error
      );
      failCount++;
    }
  }

  return {
    successCount,
    failCount,
  };
}
