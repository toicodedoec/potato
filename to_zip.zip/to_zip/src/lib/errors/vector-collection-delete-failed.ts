export class VectorCollectionDeleteFailed extends Error {
  constructor(collectionName: string) {
    super(`Failed to delete vector collection: ${collectionName}`);

    Object.setPrototypeOf(this, VectorCollectionDeleteFailed.prototype);
  }
}
