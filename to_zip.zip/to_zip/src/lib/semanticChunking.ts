/**
 * Inspired by the following sources:
 * - https://weaviate.io/blog/late-chunking
 * - https://github.com/jparkerweb/semantic-chunking/
 * - https://github.com/tsensei/Semantic-Chunking-Typescript
 */
import { split as splitSentences } from "sentence-splitter";
import { encoding_for_model } from "tiktoken";

import { openai } from "./openai";
import { cosineSimilarity, EMBEDDING_MODEL } from "./textHelpers";

/**
 * Maximum number of sentences to process at once in the similarity matrix.
 * Beyond this, the O(n²) similarity matrix becomes too large for memory.
 * 2000 sentences → ~30MB similarity matrix, which is manageable.
 */
const MAX_SENTENCES_PER_WINDOW = 2000;

const splitIntoBatches = (sentences: string[], tokenLimit: number) => {
  const batches: string[][] = [];
  const enc = encoding_for_model(EMBEDDING_MODEL);
  let currentBatch: string[] = [];
  let currentTokenCount = 0;

  for (const sentence of sentences) {
    const sentenceTokens = enc.encode(sentence).length;

    if (
      currentTokenCount + sentenceTokens > tokenLimit &&
      currentBatch.length > 0
    ) {
      batches.push(currentBatch);
      currentBatch = [];
      currentTokenCount = 0;
    }

    // Handle sentences that are longer than the token limit
    if (sentenceTokens > tokenLimit) {
      if (currentBatch.length > 0) {
        batches.push(currentBatch);
        currentBatch = [];
        currentTokenCount = 0;
      }
      // Split the sentence into batches of the token limit
      const batch = splitIntoBatches([sentence], tokenLimit);
      batches.push(...batch);
      continue;
    }

    // Add the sentence to the current batch
    currentBatch.push(sentence);
    currentTokenCount += sentenceTokens;
  }

  // Add the last batch if it's not empty
  if (currentBatch.length > 0) {
    batches.push(currentBatch);
  }

  enc.free();
  return batches;
};

/**
 * This function is used to chunk text into semantically meaningful chunks.
 * 1. It gets embeddings for each sentence in the text
 *  1.1. Uses the full document text to get embeddings
 *  1.2. Splits the text into batches to avoid the token limit of the embedding model
 * 2. Calculates semantic similarity between all sentences
 * 3. Groups similar sentences together based on their semantic meaning
 * 4. Ensures each chunk stays within token limits while preserving semantic relationships
 * @param text - The text to chunk
 * @param tokenLimit - Maximum tokens per chunk
 * @returns Array of semantically coherent text chunks
 */
export async function semanticChunking(
  text: string,
  tokenLimit = 8000,
  chunkTokenLimit = 200,
  sentenceSimilarityThreshold = 0.9,
  minClusterSize = 3
): Promise<string[]> {
  const sentences = splitSentences(text)
    .map((sentence) => sentence.raw.trim().replace(/\s+/g, " "))
    .filter((sentence) => sentence.length > 0);
  if (sentences.length <= 1) {
    return [text];
  }

  const enc = encoding_for_model(EMBEDDING_MODEL);

  // Process sentences in windows to avoid O(n²) memory usage for the similarity matrix.
  // For large documents the full n×n matrix can exhaust the heap.
  const allClusters: number[][] = [];

  for (
    let windowStart = 0;
    windowStart < sentences.length;
    windowStart += MAX_SENTENCES_PER_WINDOW
  ) {
    const windowEnd = Math.min(
      windowStart + MAX_SENTENCES_PER_WINDOW,
      sentences.length
    );
    const windowSentences = sentences.slice(windowStart, windowEnd);

    // Get embeddings for sentences in this window
    const sentenceBatches = splitIntoBatches(windowSentences, tokenLimit);
    if (windowStart === 0) {
      console.log(
        `├── Processing ${sentences.length} sentences in ${Math.ceil(sentences.length / MAX_SENTENCES_PER_WINDOW)} window(s)`
      );
    }
    const windowEmbeddings: number[][] = [];

    for (const batch of sentenceBatches) {
      const embeddingResponse = await openai.embeddings.create({
        model: EMBEDDING_MODEL,
        input: batch,
        encoding_format: "float",
      });

      windowEmbeddings.push(
        ...embeddingResponse.data.map((item) => item.embedding)
      );
    }

    // Calculate similarity matrix only for this window
    const windowSize = windowSentences.length;
    const similarityMatrix: number[][] = [];
    for (let i = 0; i < windowSize; i++) {
      similarityMatrix[i] = [];
      for (let j = 0; j < windowSize; j++) {
        similarityMatrix[i][j] = cosineSimilarity(
          windowEmbeddings[i],
          windowEmbeddings[j]
        );
      }
    }

    // Create semantic clusters within this window
    const visited = new Set<number>();
    const clusters: number[][] = [];

    for (let i = 0; i < windowSize; i++) {
      if (visited.has(i)) continue;

      const cluster: number[] = [i];
      visited.add(i);

      for (let j = 0; j < windowSize; j++) {
        if (i === j || visited.has(j)) continue;

        if (similarityMatrix[i][j] >= sentenceSimilarityThreshold) {
          cluster.push(j);
          visited.add(j);
        }
      }

      clusters.push(cluster);
    }

    // Merge small clusters with their most similar neighbors
    let mergedClusters: number[][] = [...clusters];
    while (true) {
      const smallClusters = mergedClusters.filter(
        (cluster) => cluster.length < minClusterSize
      );

      if (smallClusters.length === 0) break;

      let merged = false;
      for (const smallCluster of smallClusters) {
        if (smallCluster.length === 0) continue;

        let bestClusterIdx = -1;
        let bestAvgSimilarity = 0;

        for (let i = 0; i < mergedClusters.length; i++) {
          const candidateCluster = mergedClusters[i];
          if (
            candidateCluster === smallCluster ||
            candidateCluster.length === 0
          )
            continue;

          let totalSim = 0,
            count = 0;
          for (const srcIdx of smallCluster) {
            for (const tgtIdx of candidateCluster) {
              totalSim += similarityMatrix[srcIdx][tgtIdx];
              count++;
            }
          }

          const avgSim = count > 0 ? totalSim / count : 0;
          if (avgSim > bestAvgSimilarity) {
            bestAvgSimilarity = avgSim;
            bestClusterIdx = i;
          }
        }

        if (
          bestClusterIdx >= 0 &&
          bestAvgSimilarity > sentenceSimilarityThreshold * 0.8
        ) {
          mergedClusters[bestClusterIdx] = [
            ...mergedClusters[bestClusterIdx],
            ...smallCluster,
          ];
          mergedClusters = mergedClusters.filter((c) => c !== smallCluster);
          merged = true;
          break;
        }
      }

      if (!merged) break;
    }

    // Convert window-local indices to global indices
    for (const cluster of mergedClusters) {
      allClusters.push(cluster.map((idx) => idx + windowStart));
    }
  }

  // Sort clusters by document order
  allClusters.forEach((cluster) => cluster.sort((a, b) => a - b));
  allClusters.sort((a, b) => a[0] - b[0]);

  // Form chunks from clusters while respecting token limits
  const chunks: string[] = [];
  let currentChunk: string[] = [];
  let currentTokenCount = 0;

  for (const cluster of allClusters) {
    const clusterSentences = cluster.map((idx) => sentences[idx]);
    const clusterText = clusterSentences.join(" ");
    const clusterTokenCount = enc.encode(clusterText).length;

    if (currentTokenCount + clusterTokenCount <= chunkTokenLimit) {
      currentChunk.push(clusterText);
      currentTokenCount += clusterTokenCount;
    } else {
      if (clusterTokenCount > chunkTokenLimit) {
        // Save current chunk first
        if (currentChunk.length > 0) {
          chunks.push(currentChunk.join(" "));
          currentChunk = [];
          currentTokenCount = 0;
        }

        let subChunk: string[] = [];
        let subChunkTokens = 0;

        for (const sentenceIdx of cluster) {
          const sentence = sentences[sentenceIdx];
          const sentenceTokens = enc.encode(sentence).length;

          if (subChunkTokens + sentenceTokens <= chunkTokenLimit) {
            subChunk.push(sentence);
            subChunkTokens += sentenceTokens;
          } else {
            if (subChunk.length > 0) {
              chunks.push(subChunk.join(" "));
              subChunk = [sentence];
              subChunkTokens = sentenceTokens;
            } else {
              const words = sentence.split(/\s+/);
              let wordChunk: string[] = [];
              let wordChunkTokens = 0;

              for (const word of words) {
                const wordTokens = enc.encode(word + " ").length;
                if (wordChunkTokens + wordTokens <= chunkTokenLimit) {
                  wordChunk.push(word);
                  wordChunkTokens += wordTokens;
                } else {
                  chunks.push(wordChunk.join(" "));
                  wordChunk = [word];
                  wordChunkTokens = wordTokens;
                }
              }

              if (wordChunk.length > 0) {
                chunks.push(wordChunk.join(" "));
              }
            }
          }
        }

        if (subChunk.length > 0) {
          chunks.push(subChunk.join(" "));
        }
      } else {
        chunks.push(currentChunk.join(" "));
        currentChunk = [clusterText];
        currentTokenCount = clusterTokenCount;
      }
    }
  }

  if (currentChunk.length > 0) {
    chunks.push(currentChunk.join(" "));
  }

  enc.free();
  return chunks;
}
