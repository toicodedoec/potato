import axios from "axios";

import { PageText, PdfExtractor } from "./pdf-extractor";

class PdfIngestionExtractor implements PdfExtractor {
  /**
   * Extracts text content from each page of a PDF file using the pdf-ingestion-service.
   * @param docUrl - URL to the PDF file.
   */
  async extractPDF(docUrl: string): Promise<PageText[]> {
    const serviceUrl = process.env["PDF_INGESTION_SERVICE_URL"];

    if (!serviceUrl) {
      throw new Error("PDF_INGESTION_SERVICE_URL is not set");
    }

    const { data, status } = await axios.post(serviceUrl, {
      url: docUrl,
      use_gpt: process.env["PDF_INGESTION_USE_GPT"] === "true",
    });

    if (status !== 200) {
      throw new Error(`Error extracting PDF: ${status}`);
    }

    if (!data.markdown) {
      throw new Error(
        "No markdown content returned from PDF ingestion service"
      );
    }

    // Convert the markdown response to the PageText format
    const markdownContent = data.markdown;
    const pages = this.splitContentIntoPages(markdownContent);
    return pages;
  }

  /**
   * Splits markdown content into pages using the page markers.
   */
  private splitContentIntoPages(content: string): PageText[] {
    const pageMarkerRegex = /<!--\s*PAGE\s+(\d+)\s*-->/g;
    const pageMatches = content.split(pageMarkerRegex);

    if (pageMatches.length > 1) {
      const pages: PageText[] = [];

      // Skip the first element as it's content before any page marker
      for (let i = 1; i < pageMatches.length; i += 2) {
        const pageNumber = parseInt(pageMatches[i], 10);
        const pageContent = pageMatches[i + 1];

        if (pageContent && pageContent.trim()) {
          pages.push({
            pageNumber,
            text: pageContent.trim(),
          });
        }
      }

      if (pages.length > 0) {
        return pages;
      }
    }

    // Treat the entire content as a single page
    return [
      {
        pageNumber: 1,
        text: content.trim(),
      },
    ];
  }
}

export default PdfIngestionExtractor;
