import axios from "axios";

import { PageText, PdfExtractor } from "./pdf-extractor";

class UnstructuredPdfExtractor implements PdfExtractor {
  /**
   * Extracts text content from each page of a PDF file using unstructured in a micro service.
   * @param docUrl - URL to the PDF file.
   * @returns A promise that resolves to an array of PageText objects.
   */
  async extractPDF(docUrl: string): Promise<PageText[]> {
    const { data, status } = await axios.post(
      process.env["UNSTRUCTURED_INGESTION_SERVICE_URL"] as string,
      {
        url: docUrl,
      }
    );

    if (status !== 200) {
      throw new Error(`Error extracting PDF: ${status}`);
    }

    return data;
  }
}

export default UnstructuredPdfExtractor;
