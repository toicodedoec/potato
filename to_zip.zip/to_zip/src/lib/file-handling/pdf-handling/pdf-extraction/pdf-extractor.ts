import { IngestionMode } from "@rag/common/constants";

import PdfIngestionExtractor from "./pdf-ingestion-extractor";
import Pdf2JsonPdfExtractor from "./pdf2json-pdf-extractor";
import UnstructuredPdfExtractor from "./unstructured-pdf-extractor";

export enum PageChunkType {
  TEXT = "TEXT",
  TABLE = "TABLE",
}

export interface PageChunks {
  text: string;
  type: PageChunkType;
}

export interface PageText {
  pageNumber: number;
  text: string;
  chunks?: PageChunks[];
}

export interface PdfExtractor {
  extractPDF(docUrl: string): Promise<PageText[]>;
}

const pdfExtractorFactory = (ingestionMode?: IngestionMode): PdfExtractor => {
  const selectedIngestionMode =
    ingestionMode ?? process.env["PDF_EXTRACTOR_TYPE"];
  switch (selectedIngestionMode) {
    case "pdfIngestion":
      return new PdfIngestionExtractor();
    case "unstructured":
      return new UnstructuredPdfExtractor();
    case "pdf2json":
    default:
      console.warn("Invalid ingestion mode. Using default (pdf2json).");
      return new Pdf2JsonPdfExtractor();
  }
};

export default pdfExtractorFactory;
