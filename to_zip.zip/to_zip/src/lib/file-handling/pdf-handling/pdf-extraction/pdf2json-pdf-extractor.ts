import { deleteFileFromTmp, downloadFileToTmp } from "@rag/server-utils";
import PDFParser from "pdf2json";

import { PageText, PdfExtractor } from "./pdf-extractor";

class Pdf2JsonPdfExtractor implements PdfExtractor {
  async extractPDF(docUrl: string): Promise<PageText[]> {
    const fileTmpPath = await downloadFileToTmp(docUrl);

    const pages = await this.extractLocalPDF(fileTmpPath);

    deleteFileFromTmp(fileTmpPath);

    return pages;
  }

  /**
   * Extracts text content from each page of a PDF file using pdf2json.
   * @param filePath - Path to the PDF file.
   * @returns A promise that resolves to an array of PageText objects.
   */
  async extractLocalPDF(filePath: string): Promise<PageText[]> {
    return new Promise((resolve, reject) => {
      const pdfParser = new PDFParser();

      pdfParser.on("pdfParser_dataError", (errData: Error | { parserError: Error }) => {
        const parserError =
          errData instanceof Error ? errData : errData.parserError;
        console.error("Error extracting text per page:", parserError);
        reject(parserError);
      });

      pdfParser.on("pdfParser_dataReady", (pdfData: { Pages: any[] }) => {
        const pagesText: PageText[] = pdfData.Pages.map(
          (page: any, index: number) => {
            const pageText = page.Texts.map((text: any) => {
              return decodeURIComponent(text.R[0].T);
            }).join(" ");
            return { pageNumber: index + 1, text: pageText };
          }
        );
        resolve(pagesText);
      });

      pdfParser.loadPDF(filePath);
    });
  }
}

export default Pdf2JsonPdfExtractor;
