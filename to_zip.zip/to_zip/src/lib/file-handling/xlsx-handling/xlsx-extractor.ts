import * as XLSX from "xlsx";

import { PageText } from "../pdf-handling/pdf-extraction/pdf-extractor";

class XlsxExtractor {
  async extractXlsx(url: string): Promise<PageText[]> {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to fetch XLSX file: ${response.statusText}`);
      }

      const arrayBuffer = await response.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: "array" });
      const sheets = this.extractSheetsContent(workbook);

      return sheets.map((sheet, index) => ({
        pageNumber: index + 1,
        text: sheet.content.trim(),
      }));
    } catch (error) {
      console.error("Error extracting XLSX:", error);
      throw error;
    }
  }

  private extractSheetsContent(
    workbook: XLSX.WorkBook
  ): Array<{ name: string; content: string }> {
    const sheets: Array<{ name: string; content: string }> = [];

    workbook.SheetNames.forEach((sheetName) => {
      const worksheet = workbook.Sheets[sheetName];

      const content = this.worksheetToJson(worksheet);

      if (content.trim()) {
        sheets.push({
          name: sheetName,
          content: content,
        });
      }
    });

    return sheets;
  }

  private worksheetToJson(worksheet: XLSX.WorkSheet): string {
    const json = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
    return JSON.stringify(json, null, 2);
  }
}

export default new XlsxExtractor();
