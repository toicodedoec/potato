import { IngestionMode } from '@rag/common/constants';

import docxExtractor from './docx-handling/docx-extractor';
import markdownExtractor from './md-handling/md-extractor';
import pdfExtractor, { PageText } from './pdf-handling/pdf-extraction/pdf-extractor';
import xlsxExtractor from './xlsx-handling/xlsx-extractor';

function getFileExtension(filePath: string): string {
  return filePath.split('.').pop()?.toLowerCase() || '';
}

function isMarkdownFile(filePath: string): boolean {
  const ext = getFileExtension(filePath);
  return ext === 'md' || ext === 'markdown';
}

function isPdfFile(filePath: string): boolean {
  return getFileExtension(filePath) === 'pdf';
}

function isDocxFile(filePath: string): boolean {
  return getFileExtension(filePath) === 'docx';
}

function isXlsxFile(filePath: string): boolean {
  const ext = getFileExtension(filePath);
  return ext === 'xlsx' || ext === 'xls';
}

const extractFileContent = async (
  filePath: string,
  ingestionMode?: IngestionMode
): Promise<PageText[]> => {
  if (isMarkdownFile(filePath)) {
    return markdownExtractor.extractMarkdown(filePath);
  } else if (isPdfFile(filePath)) {
    return pdfExtractor(ingestionMode).extractPDF(filePath);
  } else if (isDocxFile(filePath)) {
    return docxExtractor.extractDocx(filePath);
  } else if (isXlsxFile(filePath)) {
    return xlsxExtractor.extractXlsx(filePath);
  } else {
    throw new Error('Unsupported file type');
  }
};

export default extractFileContent;
