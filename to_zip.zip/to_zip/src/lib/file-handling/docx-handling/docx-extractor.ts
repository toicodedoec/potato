import mammoth from "mammoth";

import { PageText } from "../pdf-handling/pdf-extraction/pdf-extractor";

class DocxExtractor {
  async extractDocx(url: string): Promise<PageText[]> {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to fetch DOCX file: ${response.statusText}`);
      }

      const arrayBuffer = await response.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);

      const result = await mammoth.convertToHtml({ buffer });
      const htmlContent = result.value;

      return [
        {
          pageNumber: 1,
          text: result.value,
        },
      ];
    } catch (error) {
      console.error("Error extracting DOCX as HTML:", error);
      throw error;
    }
  }
}

export default new DocxExtractor();
