import { PageText } from "../pdf-handling/pdf-extraction/pdf-extractor";

class MarkdownExtractor {
  async extractMarkdown(url: string): Promise<PageText[]> {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(
          `Failed to fetch markdown file: ${response.statusText}`
        );
      }

      const content = await response.text();

      const sections = this.splitByHeaders(content);

      return sections.map((section, index) => ({
        pageNumber: index + 1,
        text: section.trim(),
      }));
    } catch (error) {
      console.error("Error extracting markdown:", error);
      throw error;
    }
  }

  private splitByHeaders(content: string): string[] {
    const headerRegex = /^(#{1,2}\s+.+)$/gm;
    const sections: string[] = [];
    let currentSection = "";

    const lines = content.split("\n");

    for (const line of lines) {
      if (headerRegex.test(line) && currentSection.trim()) {
        sections.push(currentSection.trim());
        currentSection = line + "\n";
      } else {
        currentSection += line + "\n";
      }
    }

    if (currentSection.trim()) {
      sections.push(currentSection.trim());
    }

    return sections.length > 0 ? sections : [content];
  }
}

export default new MarkdownExtractor();
