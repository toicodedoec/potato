import { openai, OPENAI_MODEL } from "./openai";

const WHITESPACE_RATIO_THRESHOLD = 3;

export const normalizeText = async (content: string): Promise<string> => {
  const nonWhitespaceCharacterCount = content.replace(/\s/g, "").length;
  const whitespaceCharacterCount = content.length - nonWhitespaceCharacterCount;
  const nonWhitespaceToWhitespaceRatio =
    nonWhitespaceCharacterCount / whitespaceCharacterCount;

  if (nonWhitespaceToWhitespaceRatio > WHITESPACE_RATIO_THRESHOLD) {
    return content.replace(/\s+/g, " ").trim();
  }

  const prompt = `
        As a professional text cleaner, your job is to normalize the following text to improve readability. Retain the original meaning, semantics. Adjust formatting issues such as excessive spaces, misplaced line breaks, or unintended special characters to make the text syntactically clear and human-readable.
        Use the same language as the text. Never try to translate the text to other languages. You will only return the cleaned text without any additional text or comments.
        `;

  try {
    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: prompt },
        { role: "user", content: content },
      ],
    });
    const normalizedText = response.choices[0].message.content?.trim() || "";
    console.log("Whitespace character count", whitespaceCharacterCount);
    console.log("Non-whitespace character count", nonWhitespaceCharacterCount);
    console.log(
      "Non-whitespace to whitespace ratio",
      nonWhitespaceToWhitespaceRatio
    );
    console.log("___original text", content.slice(0, 100));
    console.log("___normalizedText", normalizedText.slice(0, 100));
    return normalizedText;
  } catch (error) {
    console.error("Error generating context:", error);
    return "";
  }
};

/**
 * Generates a succinct context for a chunk using surrounding pages.
 * @param surroundingText - The text from surrounding pages.
 * @param chunkContent - The content of the chunk.
 * @returns The generated context.
 */
export const generateContext = async (
  surroundingText: string,
  chunkContent: string
): Promise<string> => {
  const prompt = `
<document>
${surroundingText}
</document>
Here is the chunk we want to situate within the surrounding pages:
<chunk>
${chunkContent}
</chunk>
Please give a short, succinct context to situate this chunk within the surrounding pages for the purposes of improving search retrieval of the chunk. Answer only with the succinct context and nothing else. Use the same language as the surrounding text.
`;

  try {
    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [{ role: "system", content: prompt }],
    });
    // Pretty print the response
    const context = response.choices[0].message.content?.trim() || "";
    return context;
  } catch (error) {
    console.error("Error generating context:", error);
    return "";
  }
};
