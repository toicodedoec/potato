import { getWeaviateClient } from "@rag/server-utils";

export async function deleteCollection(collectionName: string): Promise<void> {
  const client = await getWeaviateClient();

  try {
    await client.collections.delete(collectionName);
  } catch (error: unknown) {
    const message = `Failed to delete collection ${collectionName}`;
    console.error(message, error);
    throw new Error(message);
  }

  return;
}

export async function getCollection(collectionName: string) {
  const client = await getWeaviateClient();

  try {
    return client.collections.get(collectionName);
  } catch (error: unknown) {
    const message = `Failed to get collection ${collectionName}`;
    console.error(message, error);
    throw new Error(message);
  }
}

export async function doesCollectionExist(
  collectionName: string
): Promise<boolean> {
  const collection = await getCollection(collectionName);
  return collection.exists();
}

export async function deleteDocumentFromVectorCollection(
  collectionName: string,
  fileUrl: string
): Promise<void> {
  const collection = await getCollection(collectionName);

  try {
    await collection.data.deleteMany(
      collection.filter.byProperty("url").equal(fileUrl)
    );
  } catch (error: unknown) {
    const message = `Failed to delete document ${fileUrl} from collection ${collectionName}`;
    console.error(message, error);
    throw new Error(message);
  }
}
