import {
  Document,
  DocumentMetadata,
  DocumentStatus,
  VectorizationConfiguration,
  prisma,
} from "@rag/db";
import { INGESTION_MODES } from '@rag/common/constants';
import { joinUrlSegments } from '@rag/common/utils';
import { getWeaviateClient } from '@rag/server-utils';
import { Collection } from 'weaviate-client';

import extractFileContent from './file-handling/file-content-extractor';
import { PageChunkType, PageText } from './file-handling/pdf-handling/pdf-extraction/pdf-extractor';
import { generateContext } from './generateContext';
import { semanticChunking } from './semanticChunking';
import { chunkText as simpleChunking } from './simpleChunking';
import { preprocessText } from './textHelpers';

const concurrencyLimit = 5;

async function handleChunkPromises(chunkPromises: Promise<unknown>[], limit: number) {
  const results = [];
  while (chunkPromises.length > 0) {
    const batch = chunkPromises.splice(0, limit);
    const settled = await Promise.allSettled(batch);
    results.push(...settled.map((result) => (result.status === 'fulfilled' ? result.value : null)));
  }
  return results.filter((result) => result !== null);
}

function concatenateTextChunks(page: PageText, previousPage?: PageText, nextPage?: PageText) {
  const lastChunkOfPreviousPage = previousPage?.chunks?.slice(-1)[0];
  const firstChunkOfNextPage = nextPage?.chunks?.slice(0)[0];
  const allChunks = [
    ...(lastChunkOfPreviousPage ? [lastChunkOfPreviousPage] : []),
    ...(page.chunks ?? []),
    ...(firstChunkOfNextPage ? [firstChunkOfNextPage] : []),
  ];

  return allChunks
    ?.filter((chunk) => chunk.type === PageChunkType.TEXT)
    .map((chunk) => chunk.text)
    .join('\n');
}

export const ingestionService = {
  name: 'ingestion',
  description: 'Webhook for ingesting new data into the RAG system',
  method: 'POST',
  handler: handleIngestionCommand,
};

type IngestionCommand = {
  docs: (Document & { metadata?: DocumentMetadata[] })[];
  collectionName: string;
};

interface DataObject extends Record<string, any> {
  body: string;
  context: string;
  pageNumber: number;
  fileName: string;
  title: string;
  priority: number;
}

export async function handleIngestionCommand({ docs, collectionName }: IngestionCommand) {
  const client = await getWeaviateClient();
  const collection = client.collections.get(collectionName);

  console.log(`Total documents to process: ${docs.length}`);

  let successCount = 0;
  let failCount = 0;

  for (const doc of docs) {
    try {
      if (doc.status !== DocumentStatus.in_progress) continue;

      const dataObjects: DataObject[] = [];

      try {
        await deleteExistingData(collection, doc.filePath);
      } catch (error) {
        console.error('Cannot delete existing data', error);
      }

      if (doc.ingestionMode && !INGESTION_MODES.includes(doc.ingestionMode)) {
        throw new Error('No correct ingestion mode provided');
      }

      const docUrl = joinUrlSegments(doc.fileHost, doc.filePath);
      const pages = await extractFileContent(docUrl, doc.ingestionMode ?? undefined);

      console.log(`\n📄 Processing: ${doc.filePath}`);
      console.log(`├── All: ${docs.length} –- Success: ${successCount} –- Fail: ${failCount}`);
      console.log(`├── Extracted ${pages.length} pages`);

      const cleanedPages = await Promise.all(
        pages.map(async (page, index) => {
          const nextPage = pages[index + 1];
          const previousPage = pages[index - 1];

          const pageText = page.chunks
            ? concatenateTextChunks(page, previousPage, nextPage)
            : page.text;

          return {
            ...page,
            pageNumber: page.pageNumber,
            text: await preprocessText(pageText),
          };
        })
      );

      const metadata = JSON.stringify(
        doc.metadata && doc.metadata.length
          ? doc.metadata.map(({ key, value }) => ({ key, value }))
          : {}
      );
      if (doc.vectorizationConfiguration === VectorizationConfiguration.semanticChunking) {
        // Semantic Chunking - using the full text
        const fullText = cleanedPages.map((page) => page.text).join('\n');
        const chunks = await semanticChunking(fullText);

        // Context and page number are not applicable for semantic chunking
        // since the chunks are generated from the full text's sentences
        // there is no page number and context / chunk
        dataObjects.push(
          ...chunks.map((chunk) => {
            return {
              body: chunk,
              context: '',
              pageNumber: 0,
              fileName: doc.filePath,
              title: doc.name,
              priority: doc.priority,
              url: docUrl,
              metadata,
            };
          })
        );
      } else {
        // Simple Chunking
        for (let i = 0; i < cleanedPages.length; i++) {
          const currentPage = cleanedPages[i];
          if (!currentPage.text) continue;

          const surroundingText = [
            cleanedPages[i - 1]?.text || '',
            currentPage.text,
            cleanedPages[i + 1]?.text || '',
          ].join(' ');

          const tableChunksArray =
            currentPage.chunks
              ?.filter((chunk) => chunk.type === PageChunkType.TABLE)
              .map((chunk) => chunk.text) ?? [];

          const currentPageChunks = await getPageChunks(
            currentPage.text,
            doc.vectorizationConfiguration ?? VectorizationConfiguration.simpleChunking
          );

          const chunks = currentPage.chunks
            ? [...tableChunksArray, ...currentPageChunks]
            : currentPageChunks;

          const chunkPromises = chunks.map(async (chunk) => {
            let context = '';
            try {
              context = await generateContext(surroundingText, chunk);
            } catch (error) {
              console.error('Error generating context:', error);
            }

            return {
              body: chunk,
              context: context,
              pageNumber: currentPage.pageNumber,
              fileName: doc.filePath,
              title: doc.name,
              priority: doc.priority,
              url: docUrl,
              metadata,
            };
          });

          const chunkDataObjects = await handleChunkPromises(chunkPromises, concurrencyLimit);
          dataObjects.push(...(chunkDataObjects as DataObject[]));
        }
      }

      console.log('└── Saving data to collection:', collectionName);
      const batchSize = 100;
      for (let i = 0; i < dataObjects.length; i += batchSize) {
        const batch = dataObjects.slice(i, i + batchSize);
        await collection.data.insertMany(batch);
      }

      await prisma.document.update({
        where: {
          id: doc.id,
        },
        data: {
          pageCount: pages.length,
          status: DocumentStatus.vectorized,
        },
      });

      successCount++;
    } catch (error) {
      console.error(`Error processing document ${doc.name}:`, error);
      failCount++;
      await prisma.document.update({
        where: {
          id: doc.id,
        },
        data: {
          status: DocumentStatus.failed,
        },
      });
    }
  }

  console.log(`Processing complete. Success: ${successCount}, Fail: ${failCount}`);

  return {
    success: true,
    message: 'Data ingested successfully',
  };
}

async function getPageChunks(text: string, vectorizationConfiguration: VectorizationConfiguration) {
  switch (vectorizationConfiguration) {
    case VectorizationConfiguration.simpleChunking:
      return simpleChunking(text);
    default:
      throw new Error('Invalid vectorization configuration');
  }
}

async function deleteExistingData(collection: Collection, filePath: string) {
  console.log(`\n🗑️  Cleaning up existing data`);
  console.log(`├── File: ${filePath}`);
  console.log(`└── Collection: ${collection.name}`);
  await collection.data.deleteMany(collection.filter.byProperty('fileName').like(filePath));
}
