import { encoding_for_model, TiktokenModel } from "tiktoken";

import { normalizeText } from "./generateContext";

export const EMBEDDING_MODEL = process.env[
  "OPENAI_EMBEDDING_MODEL"
] as TiktokenModel;

/**
 * Preprocesses text by cleaning and normalizing.
 * @param text - The raw text
 * @returns The cleaned text.
 */
export const preprocessText = async (text: string): Promise<string> => {
  if (text.length < 50) {
    return text;
  }
  const cleanedText = await normalizeText(text);
  return cleanedText.trim();
};

export function cosineSimilarity(vec1: number[], vec2: number[]): number {
  const dotProduct = vec1.reduce((acc, val, i) => acc + val * vec2[i], 0);
  const norm1 = Math.sqrt(vec1.reduce((acc, val) => acc + val * val, 0));
  const norm2 = Math.sqrt(vec2.reduce((acc, val) => acc + val * val, 0));
  return dotProduct / (norm1 * norm2);
}

/**
 * Creates chunks that are not longer than a token limit.
 * @param text - The text to chunk
 * @param tokenLimit - The token limit of the embedding model
 * @returns An array of text chunks
 */
export function createChunksBasedOnTokenLimit(
  text: string,
  tokenLimit = 8000
): string[] {
  const enc = encoding_for_model(EMBEDDING_MODEL);
  const chunks: string[] = [];
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  let currentChunk = "";
  let currentTokenCount = 0;

  // More conservative chunking
  for (const sentence of sentences) {
    const sentenceTokens = enc.encode(sentence).length;

    // If a single sentence is too long, split it into smaller parts
    if (sentenceTokens > tokenLimit) {
      if (currentChunk) {
        chunks.push(currentChunk.trim());
        currentChunk = "";
        currentTokenCount = 0;
      }

      // Split long sentence into smaller chunks based on words
      const words = sentence.split(/\s+/);
      let tempChunk = "";
      let tempTokenCount = 0;

      for (const word of words) {
        const wordTokens = enc.encode(word + " ").length;
        if (tempTokenCount + wordTokens > tokenLimit) {
          chunks.push(tempChunk.trim());
          tempChunk = word + " ";
          tempTokenCount = wordTokens;
        } else {
          tempChunk += word + " ";
          tempTokenCount += wordTokens;
        }
      }

      if (tempChunk) {
        chunks.push(tempChunk.trim());
      }
    } else if (currentTokenCount + sentenceTokens > tokenLimit * 0.9) {
      // Using 90% of limit as safety margin
      chunks.push(currentChunk.trim());
      currentChunk = sentence + " ";
      currentTokenCount = sentenceTokens;
    } else {
      currentChunk += sentence + " ";
      currentTokenCount += sentenceTokens;
    }
  }

  if (currentChunk) {
    chunks.push(currentChunk.trim());
  }

  enc.free();
  return chunks;
}
