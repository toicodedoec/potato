import { Document, DocumentStatus, prisma } from "@rag/db";

import { doesCollectionExist } from "./collection";
import { CreateCollectionConfig, createSchema } from "./createSchema";
import { ingestionService } from "./ingestion";

export const processDocumentsApplication = async (
  applicationId: string,
  createCollectionConfig: CreateCollectionConfig,
  docs?: Document[]
) => {
  const docsToProcess: Document[] =
    docs && docs.length > 0
      ? docs
      : (await prisma.document.findMany({
          where: {
            applicationId,
            status: {
              in: [DocumentStatus.failed, DocumentStatus.unvectorized],
            },
          },
        })) as Document[];

  try {
    const application = await prisma.application.findUnique({
      where: { id: applicationId },
    });

    if (!application) {
      throw new Error("Application not found");
    }

    if (!application.vectorCollectionName) {
      throw new Error("Vector collection is not set in Application config");
    }

    await setupVectorCollectionForApplication(
      application.vectorCollectionName,
      createCollectionConfig
    );

    const documentsIdsToVectorize = docsToProcess.map((doc) => doc.id);
    await prisma.document.updateMany({
      where: {
        applicationId,
        id: {
          in: documentsIdsToVectorize,
        },
      },
      data: {
        status: DocumentStatus.in_progress,
      },
    });
    const documentsToVectorize = await prisma.document.findMany({
      where: {
        applicationId,
        id: {
          in: documentsIdsToVectorize,
        },
      },
      include: {
        metadata: true,
      },
    });

    await ingestionService.handler({
      docs: documentsToVectorize,
      collectionName: application.vectorCollectionName,
    });
  } catch (error) {
    console.error(error);
  }
};

const setupVectorCollectionForApplication = async (
  vectorCollectionName: string,
  createCollectionConfig: CreateCollectionConfig
) => {
  const collectionExists = await doesCollectionExist(vectorCollectionName);
  console.log(
    `Collections for "${vectorCollectionName}" exists:`,
    collectionExists
  );
  if (!collectionExists) {
    console.log(`Creating "${vectorCollectionName}" schema...`);
    await createSchema(vectorCollectionName, createCollectionConfig);
  }
};
