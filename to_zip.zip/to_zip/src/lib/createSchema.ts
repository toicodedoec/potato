import { getWeaviateClient } from "@rag/server-utils";
import weaviate, { dataType } from "weaviate-client";

const COLLECTION_PROPERTIES = [
  {
    name: "title",
    dataType: dataType.TEXT,
  },
  {
    name: "body",
    dataType: dataType.TEXT,
  },
  {
    name: "pageNumber",
    dataType: dataType.INT,
  },
  {
    name: "fileName",
    dataType: dataType.TEXT,
    tokenization: "field" as const,
  },
  {
    name: "url",
    dataType: dataType.TEXT,
    tokenization: "lowercase" as const,
  },
  {
    name: "date",
    dataType: dataType.DATE,
  },
  {
    name: "context",
    dataType: dataType.TEXT,
  },
  {
    name: "priority",
    dataType: dataType.INT,
    description:
      "Priority of the document for processing, higher values indicate higher priority",
  },
  {
    name: "metadata",
    dataType: dataType.TEXT,
    description: "Additional metadata for the document as JSON string",
    tokenization: "whitespace" as const,
  },
];

export type CreateCollectionConfig =
  | {
      openaiAzureApiHost: string;
      openaiEmbeddingModel: string;
      openaiAzureResourceName: string;
    }
  | {
      openaiEmbeddingModel: string;
    };

export async function createSchema(
  collectionName: string,
  createCollectionConfig: CreateCollectionConfig
) {
  const client = await getWeaviateClient();
  await client.collections.delete(collectionName);

  const useAzure = "openaiAzureApiHost" in createCollectionConfig;

  try {
    if (useAzure) {
      await client.collections.create({
        name: collectionName,
        properties: COLLECTION_PROPERTIES,
        reranker: weaviate.configure.reranker.transformers(),
        vectorizers: [
          weaviate.configure.vectorizer.text2VecAzureOpenAI({
            name: "combined_vector",
            deploymentId: createCollectionConfig.openaiEmbeddingModel,
            resourceName: createCollectionConfig.openaiAzureResourceName,
            sourceProperties: ["title", "body", "context"],
            baseURL: createCollectionConfig.openaiAzureApiHost,
          }),
        ],
      });
    } else {
      await client.collections.create({
        name: collectionName,
        properties: COLLECTION_PROPERTIES,

        reranker: weaviate.configure.reranker.transformers(),
        vectorizers: [
          weaviate.configure.vectorizer.text2VecOpenAI({
            name: "combined_vector",
            model: createCollectionConfig.openaiEmbeddingModel,
            sourceProperties: ["title", "body", "context"],
          }),
        ],
      });
    }
    console.log(`✅ Schema created for ${collectionName}`);
  } catch (error) {
    console.error("Error creating schema:", error);
  }
}

export async function getCollection(collectionName: string) {
  const client = await getWeaviateClient();
  return client.collections.get(collectionName);
}
