import OpenAI, { AzureOpenAI } from "openai";

export const OPENAI_MODEL = "gpt-4o";

export const openai =
  process.env["OPENAI_AZURE_API_HOST"] !== undefined
    ? new AzureOpenAI({
        apiKey: process.env["OPENAI_API_KEY"],
        endpoint: process.env["OPENAI_AZURE_API_HOST"],
        apiVersion: process.env["OPENAI_AZURE_API_ADA_VERSION"],
      })
    : new OpenAI({ apiKey: process.env["OPENAI_API_KEY"] });
