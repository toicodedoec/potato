/**
 * Splits text into chunks based on sentence boundaries or punctuation.
 * This version ensures that no chunk is smaller than minChunkSize.
 * @param text - The cleaned text to split.
 * @param maxChunkSize - The maximum number of characters per chunk.
 * @param minChunkSize - The minimum number of characters per chunk.
 * @returns An array of text chunks.
 */
export const chunkText = (
  text: string,
  maxChunkSize = 1000,
  minChunkSize = 200
): string[] => {
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  const chunks: string[] = [];
  let currentChunk = "";

  for (const sentence of sentences) {
    // If appending the sentence doesn't exceed maxChunkSize, just append it.
    if (currentChunk.length + sentence.length <= maxChunkSize) {
      currentChunk += sentence;
      continue;
    }

    // If adding the sentence would exceed maxChunkSize:
    if (currentChunk.length < minChunkSize) {
      // Combine sentence to currentChunk to try and meet minChunkSize
      currentChunk += sentence;
      // If still under minChunkSize, continue to next sentence without pushing
      if (currentChunk.length < minChunkSize) {
        continue;
      }
      // Otherwise, process the currentChunk further if needed.
      processAndPushChunk(currentChunk, chunks, maxChunkSize, minChunkSize);
      currentChunk = "";
      continue;
    } else {
      // currentChunk is valid, push it.
      processAndPushChunk(currentChunk, chunks, maxChunkSize, minChunkSize);
      currentChunk = "";
      // Process the sentence: It might itself be too long.
      if (sentence.length > maxChunkSize) {
        processAndPushChunk(sentence, chunks, maxChunkSize, minChunkSize);
      } else {
        currentChunk = sentence;
      }
    }
  }

  if (currentChunk.length >= minChunkSize) {
    console.log(currentChunk.length);
    chunks.push(currentChunk.trim());
  }

  return chunks;
};

/**
 * Processes a chunk of text that might exceed maxChunkSize by further splitting it
 * using comma/semicolon boundaries, and ensuring that each resulting chunk has at least
 * minChunkSize characters by merging subchunks as needed.
 *
 * @param text - The text chunk to process.
 * @param chunks - The array to push valid chunks into.
 * @param maxChunkSize - The maximum number of characters per chunk.
 * @param minChunkSize - The minimum number of characters per chunk.
 */
const processAndPushChunk = (
  text: string,
  chunks: string[],
  maxChunkSize: number,
  minChunkSize: number
) => {
  // If the chunk is within maxChunkSize, push it directly.
  if (text.length <= maxChunkSize) {
    // Check if the text meets minChunkSize
    if (text.trim().length >= minChunkSize) {
      chunks.push(text.trim());
    }
    return;
  }

  // If text is longer than maxChunkSize, attempt to split it using delimiters.
  const subchunks = text.split(/[,;]/);
  let accumulator = "";
  for (const sub of subchunks) {
    const trimmedSub = sub.trim();
    if (!trimmedSub) continue;

    if (accumulator.length + trimmedSub.length + 1 <= maxChunkSize) {
      // +1 for a space or delimiter when merging
      accumulator += accumulator ? " " + trimmedSub : trimmedSub;
    } else {
      // If the accumulator does not meet minChunkSize, combine them regardless.
      if (accumulator.length < minChunkSize) {
        accumulator += " " + trimmedSub;
        // If after combining it meets minChunkSize and isn't too long, push it.
        if (
          accumulator.length >= minChunkSize &&
          accumulator.length <= maxChunkSize
        ) {
          chunks.push(accumulator.trim());
          accumulator = "";
        }
      } else {
        chunks.push(accumulator.trim());
        accumulator = trimmedSub;
      }
    }
  }
  if (accumulator.length >= minChunkSize) {
    chunks.push(accumulator.trim());
  }
};
